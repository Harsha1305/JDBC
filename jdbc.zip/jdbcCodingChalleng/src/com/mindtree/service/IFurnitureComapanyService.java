package com.mindtree.service;

import com.mindtree.entity.FurnitureCompany;
import com.mindtree.exception.ServiceException;

public interface IFurnitureComapanyService {

	/**
	 * @param id
	 * @return FurnitureCompanyObject
	 * @throws ServiceException
	 */
	public FurnitureCompany getFurnitureCompanyByID(byte id) throws ServiceException;

}
