package com.mindtree.service;

import java.util.List;
import java.util.Set;

import com.mindtree.entity.Design;
import com.mindtree.exception.ServiceException;

public interface IDesignService {

	/**
	 * @param designs
	 * @return setOfDesigns
	 * @throws ServiceException
	 */
	public Set<Design> insertDesigns(Set<Design> designs) throws ServiceException;

	/**
	 * @param id
	 * @return setOfDesigns
	 * @throws ServiceException
	 */
	public Set<Design> getDesignsByCompanyID(byte id) throws ServiceException;

	/**
	 * @param id
	 * @param rating
	 * @return 
	 * @throws ServiceException
	 */
	public String updateDesignRatingByID(byte id, double rating) throws ServiceException;

	/**
	 * @param rating
	 * @return ListOfDesigns
	 * @throws ServiceException
	 */
	public List<Design> ListAllDetailsUsingRating(double rating) throws ServiceException;

	/**
	 * @return ListOfDesigns
	 * @throws ServiceException
	 */
	public List<Design> getAllDesigns() throws ServiceException;

}
