package com.mindtree.service.impl;

import com.mindtree.dao.IFurnitureCompanyDao;
import com.mindtree.dao.impl.FurnitureCompanyDaoImpl;
import com.mindtree.entity.FurnitureCompany;
import com.mindtree.exception.DaoException;
import com.mindtree.exception.ServiceException;
import com.mindtree.exception.impl.CompmanyIdNotFoundException;
import com.mindtree.service.IFurnitureComapanyService;

public class FurnitureCompanyServiceImpl implements IFurnitureComapanyService {
	private static IFurnitureCompanyDao dao = new FurnitureCompanyDaoImpl();

	// This method is used to get the furniture company by company id from the dao and pass it to the client
	@Override
	public FurnitureCompany getFurnitureCompanyByID(byte id) throws ServiceException {
		// TODO Auto-generated method stub

		try {
			FurnitureCompany company = dao.getFurnitureCompanyByID(id);
			if (company != null) {
				return company;
			}
			else
			{
				throw new CompmanyIdNotFoundException("Service: Company id not found");
			}
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new ServiceException("Service: Please check your id what you have entered");
		}
	}

}
