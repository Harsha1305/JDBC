package com.mindtree.service.impl;

import java.util.List;
import java.util.Set;

import com.mindtree.dao.IDesignDao;
import com.mindtree.dao.impl.DesignDaoImpl;
import com.mindtree.entity.Design;
import com.mindtree.exception.DaoException;
import com.mindtree.exception.ServiceException;
import com.mindtree.exception.impl.CompmanyIdNotFoundException;
import com.mindtree.exception.impl.DesignIdNotFoundException;
import com.mindtree.service.IDesignService;

public class DesignServiceImpl implements IDesignService {
	private static IDesignDao dao = new DesignDaoImpl();

	// This method is used to save the Designs to a particular company from dao and pass it to the client
	@Override
	public Set<Design> insertDesigns(Set<Design> designs) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			return dao.saveDesignsIntoDb(designs);
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new ServiceException("Service:Insertion not happended please check with the values");
		}
	}

	// This method is used to display the Designs to a particular company id from dao and pass it to the client
	@Override
	public Set<Design> getDesignsByCompanyID(byte id) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			Set<Design> designs = dao.getDesignsByCompanyIDFromDb(id);
			if (designs.size() > 0) {
				return designs;
			} else {
				throw new CompmanyIdNotFoundException("Service: Company id is wrong please check once");
			}

		} catch (DaoException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new ServiceException("Service: Company id is wrong please check once");
		}

	}

	// This method is used to update the design rating by Design id from dao and pass it to the client
	@Override
	public String updateDesignRatingByID(byte id, double rating) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			return dao.updateDesignRatingInDb(id, rating);
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new DesignIdNotFoundException("Service: Design id is incorrect please check once");
		}
	}

	// This method is used to list company details with the furniture details all the design rating from dao and pass it to the client
	@Override
	public List<Design> ListAllDetailsUsingRating(double rating) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			return dao.listAllDesignsUsingRatingFromDb(rating);
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new ServiceException("Service: Please provide the correct rating");
		}
	}

	// This method is used to list the design from dao and pass it to the client
	@Override
	public List<Design> getAllDesigns() throws ServiceException {
		// TODO Auto-generated method stub
		try {
			return dao.getAllDesignsFromDb();
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new ServiceException("Service: No data is presented in the Database");
		}
	}

}
