package com.mindtree.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mindtree.exception.UtilityException;

public class DBConnection {
	private static final String url="jdbc:mysql://localhost:3306/database10";
	private static final String username="root";
	private static final String password="root@123";
	
	public static Connection connection() throws UtilityException
	{
		Connection connection=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UtilityException();
		}
		try {
			 connection=DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new UtilityException();
		}
		return connection;
	}
	
	

}
