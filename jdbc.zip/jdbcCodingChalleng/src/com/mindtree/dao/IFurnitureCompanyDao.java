package com.mindtree.dao;

import com.mindtree.entity.FurnitureCompany;
import com.mindtree.exception.DaoException;

public interface IFurnitureCompanyDao {
	/**
	 * @param id
	 * @return FurnitureCompanyObject
	 * @throws DaoException
	 */
	public FurnitureCompany getFurnitureCompanyByID(byte id) throws DaoException;

}
